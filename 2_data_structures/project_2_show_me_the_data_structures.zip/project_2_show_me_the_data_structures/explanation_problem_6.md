# Union and Intersection of Two Linked Lists

	I used a union_dictionary and union_list to add values from
	the given inputs from the linked list test cases.
	The reasoning for using a dictionary is to keep my lookup
	in constant time. 

	My intersection outputs are stored into a linked list.

##### Time Complexity:
	The time complexity, for my union and intersection, appends
	values into my dictionaries. The variable "n" represents
	the amount of inputs from the two linked lists being 
	compared (from the given test cases).

##### Space Complexity:
	The space complexity is O(n) and the variable "n" is 
	dependent the size of the two linked lists being 
	compared.
